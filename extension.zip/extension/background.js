chrome.runtime.onInstalled.addListener(() => {
  console.log("Humanize.ai Extension Installed Successfully.");
});