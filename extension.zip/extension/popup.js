document.addEventListener('DOMContentLoaded', () => {
  const btn = document.getElementById('humanizeBtn');
  const input = document.getElementById('inputText');
  const output = document.getElementById('outputText');
  const modal = document.getElementById('resultModal');
  const closeBtn = document.getElementById('closeModal');
  const copyBtn = document.getElementById('copyBtn');

  // HUMANIZE CLICK
  btn.addEventListener('click', async () => {
    const text = input.value.trim();
    if (!text) return alert("Please enter text!");

    btn.innerText = "SHUFFLING SENTENCES...";
    btn.disabled = true;

    try {
      const result = await callGroqAI(text);
      output.innerText = result;
      
      // Show the Modal
      modal.classList.add('show-modal');
    } catch (error) {
      alert("Error: AI disconnected. Check your API key.");
    } finally {
      btn.innerText = "Transform Text";
      btn.disabled = false;
    }
  });

  // CLOSE MODAL
  closeBtn.addEventListener('click', () => {
    modal.classList.remove('show-modal');
  });

  // COPY BUTTON
  copyBtn.addEventListener('click', () => {
    navigator.clipboard.writeText(output.innerText);
    copyBtn.innerText = "COPIED!";
    setTimeout(() => { copyBtn.innerText = "Copy to Clipboard"; }, 2000);
  });
});

async function callGroqAI(content) {
  const API_KEY = "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"; 
  const API_URL = "https://api.groq.com/openai/v1/chat/completions";
  
  const SYSTEM_PROMPT = "Identify the language of the input text. Rewrite it to sound like a natural, human student in THAT SAME language. Use varied sentence lengths and avoid AI clichés. Respond ONLY with the rewritten text.";

  const response = await fetch(API_URL, {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${API_KEY}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      model: "llama-3.3-70b-versatile",
      messages: [
        { role: "system", content: SYSTEM_PROMPT },
        { role: "user", content: content }
      ],
      temperature: 0.7
    })
  });

  const data = await response.json();
  return data.choices[0].message.content;
}